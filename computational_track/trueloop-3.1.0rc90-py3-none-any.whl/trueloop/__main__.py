"""python -m trueloop  ->  full self-verification."""
import sys
from .selftest import verify, selftest
from . import license_status, core_fingerprint, __version__, __edition__

def main():
    print("TrueLoop Stability Contract %s (%s edition)" % (__version__, __edition__))
    print("core fingerprint %s" % core_fingerprint())
    print()
    ok = verify(verbose=True) and selftest(verbose=True)
    print()
    st = license_status()
    if st.get("expires"):
        print("evaluation activated %s, expires %s (%s days remaining)"
              % (st["activated"], st["expires"], st["days_remaining"]))
    elif st.get("activate_by"):
        print("evaluation not yet activated; it activates on first use, no later than %s, and then runs %s days"
              % (st["activate_by"], st["trial_days"]))
    else:
        print("perpetual licence, no expiry")
    print()
    print("READY FOR DEPLOYMENT" if ok else "VERIFICATION FAILED, DO NOT DEPLOY")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
