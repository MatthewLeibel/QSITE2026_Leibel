"""TrueLoop Stability Contract.

A maintenance layer for component-observable hardware. Holds a commanded
configuration at its operating point using one parallel acquisition per cycle.

    from trueloop import StabilityContract

    c = StabilityContract(n=64, x0=config, target=setpoints,
                          bounds=[[lo, hi]] * 64, tolerance=0.02)
    while running:
        out = c.step(acquire())
        apply_configuration(out["config"])

Inputs accept lists, tuples, numpy arrays, torch/jax tensors, or any
sequence-like object. No conversion code is required.

Copyright (c) 2026 NEOTECH Inc. All rights reserved. Licensed use only.
"""
import sys as _sys

__version__ = "3.1.0rc90"
__edition__ = "evaluation"

try:
    from ._core import (  # noqa: F401
        StabilityContract,
        ContractCoreError,
        LicenseExpired,
        license_status,
        core_fingerprint,
        canonical,
        CORE_VERSION,
        CORE_FINGERPRINT,
    )
except ImportError as _e:  # pragma: no cover
    raise ImportError(
        "TrueLoop could not load its compiled core on this platform.\n"
        "  python   : {}.{} ({})\n"
        "  platform : {}\n"
        "This wheel targets CPython 3.9+ with the stable ABI. If your platform "
        "is not covered, contact matthew@trueloopcompute.com for a build.\n"
        "Underlying error: {}".format(
            _sys.version_info[0], _sys.version_info[1],
            _sys.implementation.name, _sys.platform, _e)
    ) from _e

from .selftest import verify, selftest  # noqa: E402,F401

__all__ = [
    "StabilityContract", "ContractCoreError", "LicenseExpired",
    "license_status", "core_fingerprint", "verify", "selftest",
    "CORE_VERSION", "CORE_FINGERPRINT", "__version__", "__edition__",
]
