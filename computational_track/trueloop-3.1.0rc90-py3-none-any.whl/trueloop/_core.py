"""TrueLoop Stability Contract, core v3.1.0 (evaluation edition).

A maintenance layer for component-observable hardware. One instance maintains
one plant: n writable channels, one observable per channel.

    c = StabilityContract(n=..., x0=..., target=..., bounds=..., tolerance=...)
    out = c.step(measurement)      # apply out["config"], acquire, repeat

Deterministic. core_fingerprint() identifies the exact licensed law and must
equal the value in golden_vectors.json and the hosted endpoint's
/api/version -> contract_core.fingerprint.

Copyright (c) 2026 NEOTECH Inc. All rights reserved. Licensed use only.
"""

from __future__ import annotations

import hashlib
import json
import math

CORE_VERSION = "3.1.0"
CORE_FINGERPRINT = "ff7d965186e402e8b94117843df06ec1479f5a3c8b5d0a057afed5b5318ff5bb"

# ---- frozen constants (hardware-validated; not caller-tunable) ----
ETA = 0.65                 # retained-law gain
MU = 0.0                   # momentum (frozen at zero in the validated campaign)
GATE_K = 2.5               # gate opens at |rbar| > GATE_K * SE (with OPEN_PERSIST consecutive exceedances)
OPEN_PERSIST = 2           # consecutive exceedances required to open; quiet-plant duty < 1 percent
GATE_HYSTERESIS = 0.8      # gate closes at GATE_HYSTERESIS * opening threshold (fast close after noise-opens)
PROBE_ROUNDS = 3           # deterministic identification rounds when no sign declared
PROBE_AMP_FRACTION = 0.05  # probe amplitude as a fraction of the bound span
PROBE_AMP_DEFAULT = 0.15   # probe amplitude when the plant is unbounded
SLOPE_BETA = 0.4           # EW weight for the measured slope
NOISE_BETA = 0.25          # EW weight for the measured noise floor
MIN_GAIN = 0.15            # slope magnitude floor used in the drive division
RESOLVE_K = 2.0            # a slope observation counts only if |dy| > RESOLVE_K * sigma
SLOPE_MIN_MOVE = 0.25      # slope updates require |dphi| > SLOPE_MIN_MOVE * probe amplitude (no division by jitter)
EPS_MOVE = 1e-9



# ==================== licensing gate (TrueLoop distribution) ====================
_BUILD_DATE  = "2026-09-19"
_EDITION     = "evaluation"
_TRIAL_DAYS  = 90          # 0 for the licensed edition: no clock dependency at all
_ACTIVATE_BY = "2027-03-18"       # evaluation builds must be activated by this date
_WARN_DAYS   = 14


class LicenseExpired(RuntimeError):
    pass


def _today():
    import datetime as _dt
    return _dt.date.today()


def _parse(s):
    import datetime as _dt
    y, m, d = (int(v) for v in s.split("-"))
    return _dt.date(y, m, d)


def _activation_path():
    import os as _os
    base = _os.environ.get("TRUELOOP_HOME") or _os.path.join(_os.path.expanduser("~"), ".trueloop")
    return _os.path.join(base, "activation-%s-%s.json" % (CORE_FINGERPRINT[:12], _EDITION))


def _read_activation():
    import json as _json
    try:
        with open(_activation_path()) as f:
            d = _json.load(f)
        if d.get("fingerprint") == CORE_FINGERPRINT and d.get("edition") == _EDITION and d.get("activated"):
            return d
    except Exception:
        pass
    return None


def _write_activation(today):
    import json as _json, os as _os
    p = _activation_path()
    _os.makedirs(_os.path.dirname(p), exist_ok=True)
    d = {"edition": _EDITION, "fingerprint": CORE_FINGERPRINT, "build": _BUILD_DATE,
         "activated": today.isoformat(), "trial_days": _TRIAL_DAYS}
    with open(p, "w") as f:
        _json.dump(d, f)
    return d


def license_status():
    """Return the licensing state of this build. Safe to call at any time; never writes."""
    import datetime as _dt
    base = {"edition": _EDITION, "core_version": CORE_VERSION, "core_fingerprint": CORE_FINGERPRINT}
    if not _TRIAL_DAYS:
        base.update({"expires": None, "days_remaining": None, "valid": True})
        return base
    today = _today()
    build = _parse(_BUILD_DATE)
    act = _read_activation()
    if act is None:
        activate_by = _parse(_ACTIVATE_BY)
        rolled_back = today < build
        base.update({"activated": None, "activate_by": _ACTIVATE_BY, "trial_days": _TRIAL_DAYS,
                      "expires": None, "days_remaining": None,
                      "valid": (today <= activate_by) and not rolled_back,
                      "clock_rollback_detected": rolled_back})
        return base
    a = _parse(act["activated"])
    exp = a + _dt.timedelta(days=_TRIAL_DAYS)
    rolled_back = today < a
    days = (exp - today).days
    base.update({"activated": act["activated"], "activate_by": _ACTIVATE_BY, "trial_days": _TRIAL_DAYS,
                  "expires": exp.isoformat(), "days_remaining": days,
                  "valid": (days >= 0) and not rolled_back,
                  "clock_rollback_detected": rolled_back})
    return base


def _gate():
    """Licensed component."""
    if not _TRIAL_DAYS:
        return
    import sys as _sys
    st = license_status()
    if st.get("clock_rollback_detected"):
        raise LicenseExpired(
            "TrueLoop evaluation build: system date {} precedes the {} date {}. "
            "Correct the system clock or contact matthew@trueloopcompute.com."
            .format(_today().isoformat(), "activation" if st.get("activated") else "build",
                    st.get("activated") or _BUILD_DATE))
    if st["activated"] is None:
        if not st["valid"]:
            raise LicenseExpired(
                "TrueLoop evaluation build: the activation window closed on {}. "
                "Request a fresh evaluation build from matthew@trueloopcompute.com."
                .format(_ACTIVATE_BY))
        try:
            _write_activation(_today())
        except OSError as e:
            raise LicenseExpired(
                "TrueLoop evaluation build could not record its activation at {} ({}). "
                "Set TRUELOOP_HOME to a writable directory and construct the contract again."
                .format(_activation_path(), e))
        st = license_status()
        _sys.stderr.write(
            "[TrueLoop] evaluation activated on {}; it runs {} days, until {}.\n"
            .format(st["activated"], _TRIAL_DAYS, st["expires"]))
        return
    if not st["valid"]:
        raise LicenseExpired(
            "TrueLoop evaluation build expired on {}. Existing sessions were never "
            "interrupted, but new contracts cannot be created. "
            "For a perpetual licence contact matthew@trueloopcompute.com."
            .format(st["expires"]))
    if st["days_remaining"] is not None and st["days_remaining"] <= _WARN_DAYS:
        _sys.stderr.write(
            "[TrueLoop] evaluation build expires in {} day(s), on {}.\n"
            .format(st["days_remaining"], st["expires"]))
# ===============================================================================



# ==================== input adaptation (drop-in compatibility) ====================
def _seq(v, n, name):
    """Licensed component."""
    if v is None:
        return None
    if isinstance(v, (list, tuple)):
        seq = v
    elif hasattr(v, "tolist"):          # numpy, torch, jax
        seq = v.tolist()
        if seq and isinstance(seq[0], (list, tuple)):
            raise ContractCoreError("%s must be one dimensional, got nested" % name)
    elif hasattr(v, "__len__") and hasattr(v, "__getitem__"):
        seq = list(v)
    elif hasattr(v, "__iter__"):
        seq = list(v)
    else:
        raise ContractCoreError("%s must be a sequence of length %d" % (name, n))
    if len(seq) != n:
        raise ContractCoreError("%s must have length %d, got %d" % (name, n, len(seq)))
    out = []
    for x in seq:
        try:
            out.append(float(x))
        except (TypeError, ValueError):
            raise ContractCoreError("%s contains a non-numeric entry" % name)
    return out


def _pairs(v, n):
    """Coerce bounds: None, (lo,hi), [[lo,hi]]*n, or an (n,2) array."""
    if v is None or (isinstance(v, str) and v == "none"):
        return None
    if hasattr(v, "tolist"):
        v = v.tolist()
    if (isinstance(v, (list, tuple)) and len(v) == 2
            and not isinstance(v[0], (list, tuple))):
        return [float(v[0]), float(v[1])]
    out = []
    for b in v:
        if hasattr(b, "tolist"):
            b = b.tolist()
        out.append([float(b[0]), float(b[1])])
    if len(out) != n:
        raise ContractCoreError("bounds must have length %d, got %d" % (n, len(out)))
    return out
# =================================================================================


def _finite(x):
    return isinstance(x, (int, float)) and math.isfinite(x)


class ContractCoreError(ValueError):
    pass


class StabilityContract:
    """Licensed component."""

    def __init__(self, n, *, x0=None, target=None, bounds=None, link_signs=None,
                 measurement_noise=None, tolerance=None, eta=None, drift_per_cycle=None,
                 on_nonfinite='hold'):
        _gate()
        if not isinstance(n, int) or n < 1:
            raise ContractCoreError("n must be a positive integer")
        self.n = n
        self.eta = float(eta) if eta is not None else ETA
        if not (0.0 < self.eta <= 1.0):
            raise ContractCoreError("eta must be in (0, 1]")
        x0 = _seq(x0, n, 'x0')
        target = _seq(target, n, 'target')
        bounds = _pairs(bounds, n)
        if link_signs is not None:
            link_signs = _seq(link_signs, n, 'link_signs')
        if measurement_noise is not None and not isinstance(measurement_noise, (int, float)):
            measurement_noise = _seq(measurement_noise, n, 'measurement_noise')
        if tolerance is not None and not isinstance(tolerance, (int, float)):
            tolerance = _seq(tolerance, n, 'tolerance')
        self.on_nonfinite = str(on_nonfinite)
        if self.on_nonfinite not in ('hold', 'raise'):
            raise ContractCoreError("on_nonfinite must be 'hold' or 'raise'")
        self._nonfinite = []
        self.phi = [float(x0[i]) for i in range(n)] if x0 is not None else [0.0] * n
        self.phi_prev = list(self.phi)
        self.target = [float(target[i]) for i in range(n)] if target is not None else None
        if bounds is None or bounds == "none":
            self.lo, self.hi = [-1e18] * n, [1e18] * n
        elif isinstance(bounds, (list, tuple)) and len(bounds) == 2 and _finite(bounds[0]):
            self.lo, self.hi = [float(bounds[0])] * n, [float(bounds[1])] * n
        else:
            self.lo = [float(b[0]) for b in bounds]
            self.hi = [float(b[1]) for b in bounds]
        for i in range(n):
            if not (self.lo[i] < self.hi[i]) and self.hi[i] < 1e17:
                raise ContractCoreError("bounds must satisfy lo < hi on every channel")
            self.phi[i] = min(self.hi[i], max(self.lo[i], self.phi[i]))
        self.sign = list(link_signs) if link_signs is not None else None
        if self.sign is not None and len(self.sign) != n:
            raise ContractCoreError("link_signs must have length n")
        self.g = [None] * n            # measured slope dy/dphi
        self.g_locked = [False] * n    # informative: slope resolved against noise
        if measurement_noise is None:
            self.sigma = [None] * n
        elif isinstance(measurement_noise, (int, float)):
            self.sigma = [max(0.0, float(measurement_noise))] * n
        else:
            self.sigma = [max(0.0, float(v)) for v in measurement_noise]
        self.drift_pc = None if drift_per_cycle is None else max(0.0, float(drift_per_cycle))
        self.tol = None
        self.tol_scalar = None
        if tolerance is not None:
            if isinstance(tolerance, (int, float)):
                self.tol = [float(tolerance)] * n
                self.tol_scalar = float(tolerance)   # aggregate-rms hold rule, the contract semantics
            else:
                self.tol = [float(v) for v in tolerance]
        self.rbar = [0.0] * n
        self.gate_open = [False] * n
        self.open_streak = [0] * n
        self.sign_conflict = [False] * n
        self.m_prev = None
        self.cycle = 0
        self.phase = "hold" if measurement_noise is None else "probe"
        self.probe_i = 0
        self._probe_dirs = [1.0] * n

    # ------------------------------------------------------------------ helpers
    def _probe_amp(self, i):
        span = self.hi[i] - self.lo[i]
        if span < 1e17:
            return PROBE_AMP_FRACTION * span
        return PROBE_AMP_DEFAULT

    def _se(self, i):
        s = self.sigma[i]
        if s is None:
            return None
        return s * math.sqrt(self.eta / (2.0 - self.eta))

    # ------------------------------------------------------------------ the law
    def step(self, measurement, target=None, apply=True):
        y = _seq(measurement, self.n, "measurement")
        bad = [i for i in range(self.n) if not math.isfinite(y[i])]
        if bad and self.on_nonfinite == "raise":
            raise ContractCoreError("measurement values must be finite")
        if bad:
            src = self.m_prev
            for i in bad:
                if src is not None and math.isfinite(src[i]):
                    y[i] = src[i]
                elif self.target is not None:
                    y[i] = self.target[i]
                else:
                    y[i] = 0.0
        self._nonfinite = bad
        if target is not None:
            self.target = _seq(target, self.n, "target")
        if self.target is None:
            raise ContractCoreError("a target vector is required")
        self.cycle += 1
        n = self.n
        clipped = []

        # ---- learn from the move that produced this measurement ----
        if self.m_prev is not None:
            for i in range(n):
                if i in self._nonfinite:
                    continue
                dphi = self.phi[i] - self.phi_prev[i]
                dy = y[i] - self.m_prev[i]
                if abs(dphi) > max(EPS_MOVE, SLOPE_MIN_MOVE * self._probe_amp(i)):
                    inst = dy / dphi
                    floor = self.sigma[i]
                    if floor is not None and self.drift_pc is not None:
                        floor = math.sqrt(floor * floor + self.drift_pc * self.drift_pc)
                    resolvable = floor is None or abs(dy) > RESOLVE_K * floor
                    # An observation that cannot be resolved against readout noise AND
                    # inter-cycle drift carries no slope information: do not fold it in.
                    if resolvable or self.g[i] is None:
                        self.g[i] = inst if self.g[i] is None else (1.0 - SLOPE_BETA) * self.g[i] + SLOPE_BETA * inst
                    if resolvable and abs(self.g[i]) >= MIN_GAIN * 1e-3:
                        self.g_locked[i] = True
                    if (self.sign is not None and self.g_locked[i]
                            and (self.g[i] > 0) != (self.sign[i] >= 0)):
                        self.sign_conflict[i] = True       # measurement contradicts the declaration: hold + surface
                    elif self.sign is not None and self.g_locked[i]:
                        self.sign_conflict[i] = False
                elif abs(dphi) <= EPS_MOVE:
                    # held channel: the innovation is drift + readout noise; feed the floor.
                    inn2 = 0.5 * dy * dy
                    if self.sigma[i] is None:
                        self.sigma[i] = math.sqrt(inn2)
                    else:
                        s2 = (1.0 - NOISE_BETA) * self.sigma[i] * self.sigma[i] + NOISE_BETA * inn2
                        self.sigma[i] = math.sqrt(s2)

        # ---- retained residual ----
        r = [self.target[i] - y[i] for i in range(n)]
        if self.tol_scalar is not None:
            rms_now = math.sqrt(sum(v * v for v in r) / n)
            if rms_now <= self.tol_scalar:
                apply = False        # the contract holds inside tolerance; learning continues
        for i in range(n):
            self.rbar[i] += self.eta * (r[i] - self.rbar[i])

        # ---- gate (per channel, opening persistence + hysteresis) ----
        for i in range(n):
            se = self._se(i)
            if se is None or se <= 0.0:
                self.gate_open[i] = True
            else:
                thr_open = GATE_K * se
                thr_close = GATE_HYSTERESIS * thr_open
                if self.gate_open[i]:
                    self.gate_open[i] = abs(self.rbar[i]) > thr_close
                    self.open_streak[i] = OPEN_PERSIST if self.gate_open[i] else 0
                else:
                    if abs(self.rbar[i]) > thr_open:
                        self.open_streak[i] += 1
                    else:
                        self.open_streak[i] = 0
                    self.gate_open[i] = self.open_streak[i] >= OPEN_PERSIST

        self.phi_prev = list(self.phi)
        next_phi = list(self.phi)

        if self.phase == "hold":
            # one dedicated repeat read seeds the measured noise floor; no motion this round.
            self.phase = "drive" if self.sign is not None else "probe"
        elif self.phase == "probe" and apply:
            amp_dir = 1.0 if (self.probe_i % 2 == 0) else -1.0
            for i in range(n):
                a = self._probe_amp(i) * amp_dir * self._probe_dirs[i]
                cand = self.phi[i] + a
                if cand > self.hi[i] or cand < self.lo[i]:
                    cand = self.phi[i] - a
                next_phi[i] = min(self.hi[i], max(self.lo[i], cand))
            self.probe_i += 1
            if self.probe_i >= PROBE_ROUNDS:
                self.phase = "drive"
        elif apply:
            for i in range(n):
                if i in self._nonfinite:
                    continue
                informative = self.g_locked[i] or self.sign is not None
                if not informative or not self.gate_open[i] or self.sign_conflict[i]:
                    continue
                g = self.g[i] if self.g[i] is not None else 0.0
                if self.sign is not None:
                    mag = max(abs(g), MIN_GAIN)
                    g_eff = (1.0 if self.sign[i] >= 0 else -1.0) * mag
                else:
                    g_eff = g if abs(g) >= MIN_GAIN else (MIN_GAIN if g >= 0 else -MIN_GAIN)
                step = self.eta * self.rbar[i] / g_eff + MU * (self.phi[i] - self.phi_prev[i])
                cand = self.phi[i] + step
                lo, hi = self.lo[i], self.hi[i]
                if cand < lo or cand > hi:
                    clipped.append(i)
                next_phi[i] = min(hi, max(lo, cand))

        self.phi = next_phi
        self.m_prev = list(y)

        informative_count = sum(
            1 for i in range(n)
            if (self.g_locked[i] or self.sign is not None) and not self.sign_conflict[i]
        )
        gates_open = sum(1 for i in range(n) if self.gate_open[i])
        rbar_rms = math.sqrt(sum(v * v for v in self.rbar) / n)
        sigmas = [s for s in self.sigma if s is not None]
        sigma_rms = math.sqrt(sum(s * s for s in sigmas) / len(sigmas)) if sigmas else None
        within = None
        if self.tol is not None:
            within = all(abs(r[i]) <= self.tol[i] for i in range(n))
        noise_limited = []
        if self.tol is not None:
            for i in range(n):
                se = self._se(i)
                if se is not None and self.tol[i] < GATE_K * se:
                    noise_limited.append(i)
        return {
            "core_version": CORE_VERSION,
            "config": list(self.phi),
            "phase": self.phase if self.phase != "drive" or self.probe_i or self.sign else self.phase,
            "cycle": self.cycle,
            "clipped": clipped,
            "gates_open": gates_open,
            "informative_count": informative_count,
            "identification_complete": informative_count == n,
            "residual_rms": rbar_rms,
            "noise_floor_rms": sigma_rms,
            "within_tolerance": within,
            "noise_limited_channels": noise_limited,
            "sign_conflicts": [i for i in range(n) if self.sign_conflict[i]],
            "nonfinite_channels": list(self._nonfinite),
        }

    # ------------------------------------------------------------------ state
    def state(self):
        return {
            "version": CORE_VERSION,
            "n": self.n, "eta": self.eta,
            "phi": list(self.phi), "phi_prev": list(self.phi_prev),
            "target": list(self.target) if self.target is not None else None,
            "lo": list(self.lo), "hi": list(self.hi),
            "sign": list(self.sign) if self.sign is not None else None,
            "g": [g for g in self.g], "g_locked": list(self.g_locked),
            "sigma": [s for s in self.sigma], "tol": list(self.tol) if self.tol else None,
            "rbar": list(self.rbar), "gate_open": list(self.gate_open),
            "open_streak": list(self.open_streak), "sign_conflict": list(self.sign_conflict),
            "tol_scalar": self.tol_scalar,
            "drift_pc": self.drift_pc,
            "m_prev": list(self.m_prev) if self.m_prev is not None else None,
            "cycle": self.cycle, "phase": self.phase, "probe_i": self.probe_i,
        }

    @classmethod
    def restore(cls, s):
        c = cls(int(s["n"]), eta=s.get("eta"))
        for k in ("phi", "phi_prev", "lo", "hi", "rbar", "gate_open", "g", "g_locked", "sigma", "open_streak", "sign_conflict"):
            setattr(c, k, list(s[k]))
        c.target = list(s["target"]) if s.get("target") is not None else None
        c.sign = list(s["sign"]) if s.get("sign") is not None else None
        c.tol = list(s["tol"]) if s.get("tol") else None
        c.tol_scalar = s.get("tol_scalar")
        c.drift_pc = s.get("drift_pc")
        c.m_prev = list(s["m_prev"]) if s.get("m_prev") is not None else None
        c.cycle = int(s["cycle"]); c.phase = s["phase"]; c.probe_i = int(s["probe_i"])
        return c


def canonical(obj):
    return json.dumps(obj, allow_nan=False, ensure_ascii=True, separators=(",", ":"), sort_keys=True)


def core_fingerprint():
    """Licensed component."""
    return CORE_FINGERPRINT
