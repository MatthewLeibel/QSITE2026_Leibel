from typing import Any, Dict, List, Optional, Sequence, Union

CORE_VERSION: str
CORE_FINGERPRINT: str

Number = Union[int, float]
Vector = Sequence[Number]
Bounds = Union[Sequence[Number], Sequence[Sequence[Number]], None]

class ContractCoreError(ValueError): ...
class LicenseExpired(RuntimeError): ...

class StabilityContract:
    n: int
    phi: List[float]
    def __init__(
        self,
        n: int,
        *,
        x0: Optional[Vector] = ...,
        target: Optional[Vector] = ...,
        bounds: Bounds = ...,
        link_signs: Optional[Vector] = ...,
        measurement_noise: Optional[Union[Number, Vector]] = ...,
        tolerance: Optional[Union[Number, Vector]] = ...,
        eta: Optional[float] = ...,
        drift_per_cycle: Optional[Number] = ...,
        on_nonfinite: str = ...,
    ) -> None: ...
    def step(
        self,
        measurement: Vector,
        target: Optional[Vector] = ...,
        apply: bool = ...,
    ) -> Dict[str, Any]: ...
    def state(self) -> Dict[str, Any]: ...
    @classmethod
    def restore(cls, s: Dict[str, Any]) -> "StabilityContract": ...

def license_status() -> Dict[str, Any]: ...
def core_fingerprint() -> str: ...
def canonical(obj: Any) -> str: ...
