"""Golden-vector replay and behavioural self-tests, shipped readable on purpose.

A customer who can verify the artifact trusts it. These call only public API.
"""
import hashlib, json, math, os

from ._core import StabilityContract, canonical, core_fingerprint

_HERE = os.path.dirname(os.path.abspath(__file__))
_GOLDEN = os.path.join(_HERE, "golden_vectors.json")


def _replay(name):
    if name == "gain_offset_drift":
        n = 6
        gains = [1.2, -0.8, 1.0, 1.5, 0.7, -1.1]
        offsets = [0.30, 0.90, 0.10, -0.20, 0.55, 0.05]
        c = StabilityContract(n, x0=[0.0] * n, target=[0.5] * n,
                              bounds=[[-2.0, 2.0]] * n,
                              measurement_noise=0.0, tolerance=0.05)
        rows = []
        for _ in range(30):
            offsets = [o + 0.003 for o in offsets]
            y = [offsets[i] + gains[i] * c.phi[i] for i in range(n)]
            out = c.step(y)
            rows.append({"config": out["config"], "gates_open": out["gates_open"],
                         "informative": out["informative_count"], "phase": out["phase"]})
    elif name == "declared_signs_deterministic_jitter":
        n = 4
        gains = [1.0, -1.0, 1.3, 0.9]
        offsets = [0.4, 0.8, -0.1, 0.2]
        c = StabilityContract(n, x0=[0.1] * n, target=[0.5] * n,
                              bounds=[[-3.0, 3.0]] * n, link_signs=[1, -1, 1, 1],
                              measurement_noise=0.002, tolerance=0.03)
        rows = []
        for k in range(25):
            y = [offsets[i] + gains[i] * c.phi[i] + 0.002 * ((k * 7 + i * 3) % 5 - 2) / 2.0
                 for i in range(n)]
            out = c.step(y)
            rows.append({"config": out["config"], "sign_conflicts": out["sign_conflicts"],
                         "gates_open": out["gates_open"]})
    else:
        n = 5
        c = StabilityContract(n, x0=[0.5] * n, target=[0.5] * n,
                              bounds=[[-1.0, 2.0]] * n,
                              measurement_noise=0.01, tolerance=0.04)
        rows = []
        for k in range(20):
            y = [0.5 + 0.01 * ((k * 5 + i * 2) % 7 - 3) / 3.0 for i in range(n)]
            out = c.step(y)
            rows.append({"config": out["config"], "gates_open": out["gates_open"],
                         "phase": out["phase"]})
    return hashlib.sha256(canonical(rows).encode()).hexdigest()


def verify(verbose=False):
    """Replay every committed golden vector. Returns True if byte-identical."""
    g = json.load(open(_GOLDEN))
    ok = core_fingerprint() == g["core_fingerprint"]
    if verbose:
        print("golden fingerprint %s %s" % (g["core_fingerprint"],
                                            "MATCH" if ok else "MISMATCH"))
    for s in g["scenarios"]:
        got = _replay(s["name"])
        good = got == s["canonical_sha256"]
        ok &= good
        if verbose:
            print("%s %s" % ("PASS" if good else "FAIL", s["name"]))
    if verbose:
        print("BYTE-IDENTICAL: ALL GOLDEN VECTORS REPRODUCED" if ok
              else "MISMATCH, DO NOT DEPLOY")
    return bool(ok)


def selftest(verbose=False):
    """Behavioural checks including drop-in input handling."""
    results = []

    def check(name, fn):
        try:
            fn()
            results.append((name, True, ""))
        except Exception as e:  # noqa: BLE001
            results.append((name, False, "%s: %s" % (type(e).__name__, e)))

    n = 8

    def mk(**kw):
        d = dict(x0=[0.0] * n, target=[0.0] * n, bounds=[[-1.0, 1.0]] * n,
                 tolerance=0.02)
        d.update(kw)
        return StabilityContract(n, **d)

    def convergence():
        gains = [1.0 + 0.1 * i for i in range(n)]
        off = [0.6] * n
        c = StabilityContract(n, x0=[0.0] * n, target=[0.0] * n,
                              bounds=[[-4.0, 4.0]] * n, tolerance=0.02)
        x = [0.0] * n
        for _ in range(30):
            y = [off[i] + gains[i] * x[i] for i in range(n)]
            out = c.step(y)
            x = out["config"]
        assert out["residual_rms"] < 0.05, out["residual_rms"]

    def quiet_holds():
        c = StabilityContract(n, x0=[0.0] * n, target=[0.0] * n,
                              bounds=[[-1.0, 1.0]] * n,
                              measurement_noise=0.01, tolerance=0.05)
        moved = 0
        x = [0.0] * n
        for k in range(60):
            y = [0.01 * (((k * 3 + i) % 5) - 2) / 2.0 for i in range(n)]
            out = c.step(y)
            if k > 5:
                moved += sum(1 for i in range(n) if abs(out["config"][i] - x[i]) > 1e-12)
            x = out["config"]
        assert moved == 0, "quiet plant should not move, moved %d" % moved

    def determinism():
        a = _replay("gain_offset_drift")
        b = _replay("gain_offset_drift")
        assert a == b

    def nonfinite_held():
        c = mk()
        c.step([0.1] * n)
        m = [0.1] * n
        m[3] = float("nan")
        out = c.step(m)
        assert out["nonfinite_channels"] == [3]
        assert all(math.isfinite(v) for v in out["config"])

    def sequence_inputs():
        mk().step(tuple([0.1] * n))
        mk().step([0] * n)
        try:
            import numpy as np
        except ImportError:
            return
        mk().step(np.zeros(n))
        mk().step(np.zeros(n, dtype=np.float32))
        StabilityContract(n, x0=np.zeros(n), target=np.zeros(n),
                          bounds=np.array([[-1.0, 1.0]] * n),
                          tolerance=0.02).step(np.full(n, 0.2))

    def roundtrip_state():
        c = mk()
        for _ in range(4):
            c.step([0.2] * n)
        s = c.state()
        d = StabilityContract.restore(s)
        assert d.step([0.2] * n)["config"] == c.step([0.2] * n)["config"]

    def rejects_bad_input():
        try:
            mk().step([0.1] * (n + 1))
        except Exception:
            return
        raise AssertionError("wrong length must be rejected")

    check("convergence_under_offset", convergence)
    check("quiet_plant_holds", quiet_holds)
    check("determinism", determinism)
    check("nonfinite_channel_held", nonfinite_held)
    check("sequence_input_adaptation", sequence_inputs)
    check("state_roundtrip", roundtrip_state)
    check("rejects_wrong_length", rejects_bad_input)

    ok = all(r[1] for r in results)
    if verbose:
        for name, good, msg in results:
            print("%s %s%s" % ("PASS" if good else "FAIL", name,
                              "  " + msg if msg else ""))
        print("ALL SELF-TESTS PASSED" if ok else "SELF-TESTS FAILED")
    return ok
