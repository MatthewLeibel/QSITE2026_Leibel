"""Backward compatibility shim.

Existing integrations written against `import stability_contract` keep working.
New code should use `from trueloop import StabilityContract`.
"""
from trueloop import *          # noqa: F401,F403
from trueloop import (          # noqa: F401
    StabilityContract, ContractCoreError, LicenseExpired,
    license_status, core_fingerprint, canonical,
    CORE_VERSION, CORE_FINGERPRINT,
)
